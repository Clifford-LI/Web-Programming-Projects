<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Processing...</title>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
    </head>
    <script>
function setCookie(cname,cvalue,exdays) {
  var d = new Date();
  d.setTime(d.getTime() + (exdays*24*60*60*1000));
  var expires = "expires=" + d.toGMTString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}
function getCookie(cname) {
      var name = cname + "=";
      var decodedCookie = decodeURIComponent(document.cookie);
      var ca = decodedCookie.split(';');
      for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          return c.substring(name.length, c.length);
        }
      }
      return "";
    }
    function setName(name){
        setCookie("name", name, 1);
    }
        </script>
    <body>
        <?php
            $eid = $_POST['eid'];
            $pwd = $_POST['pwd'];
            
            $servername = "localhost";
            $username = "root";
            $password = "Ast20201!";
            
            $conn = mysqli_connect($servername, $username, $password);
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }

            $sql = "select * from sams.account_list where eid=".$eid;
            if($result = mysqli_query($conn, $sql)){
                if(mysqli_num_rows($result) == 0){
                    echo 'EID does not exist!';
                }
                else{
                    $row = mysqli_fetch_array($result);
                    if($row['eid']==$eid)
                        if($row['pwd']==$pwd){
                            echo $row['name'];
                            echo '<script type="text/javascript">',
                                 "setName('".$row['name']."');",
                                 '</script>'
                                 ;
                        }
                        else
                            echo 'Password incorrect!';
                }
                    
            }
            mysqli_close($conn);
        ?>
        
    </body>
</html>
