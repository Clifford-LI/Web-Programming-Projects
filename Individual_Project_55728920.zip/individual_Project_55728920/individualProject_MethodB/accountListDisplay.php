<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Displaying List...</title>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
        <style>
            URL_list{
                text-align: left;
            }
            button{
                border: none; 
                color: white; 
                background-color: #d11d80; 
                width: 90px; 
                height: 40px; 
                cursor:pointer; 
                font-weight: bold;
            }
        </style>
        <script>
            function setCookie(cname,cvalue,exdays) {
                var d = new Date();
                d.setTime(d.getTime() + (exdays*24*60*60*1000));
                var expires = "expires=" + d.toGMTString();
                document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
              }
            function getCookie(cname) {
                    var name = cname + "=";
                    var decodedCookie = decodeURIComponent(document.cookie);
                    var ca = decodedCookie.split(';');
                    for(var i = 0; i < ca.length; i++) {
                      var c = ca[i];
                      while (c.charAt(0) == ' ') {
                        c = c.substring(1);
                      }
                      if (c.indexOf(name) == 0) {
                        return c.substring(name.length, c.length);
                      }
                    }
                return "";
            }
            function setStudentEID(eid){
                setCookie("studentEID",eid,1);
            }
            function setStudentName(name){
                setCookie("studentName",name,1);
            }
            function hideBtn(cellId){
                document.getElementById(cellId).style.display = "none";
                document.getElementById("status"+cellId).innerHTML = "Present";
                document.getElementById("status"+cellId).style.color = "green";
            }
            function insertHistory(){
                var date = new Date();
                var dateStr =
                    (date.getFullYear()) + "-" +
                    ("00" + (date.getMonth()+1)).slice(-2) + "-" +
                    date.getDate() + " " +
                    ("00" + date.getHours()).slice(-2) + ":" +
                    ("00" + date.getMinutes()).slice(-2) + ":" +
                    ("00" + date.getSeconds()).slice(-2);

                setCookie("clickTime", dateStr, 1);
                
                $.ajax({
                    type:"POST",
                    async: false,
                    url:"takeAttendance_teacher.php",
                    data:{
                        courseID: getCookie("courseID"),
                        url_id: getCookie("url_id"),
                        studentEID: getCookie("studentEID"),
                        classStartTime: getCookie("classStartTime"),
                        studentName: getCookie("studentName"),
                        classTitle: getCookie("classTitle"),
                        classDuration: getCookie("classDuration"),
                        attend_time: getCookie("clickTime")
                    },
                    success: function(data){ 

                    }
                });
            }
        </script>
    </head>
    <body>
        <?php
            $eid = $_POST['eid'];
            
            $servername = "localhost";
            $username = "root";
            $password = "Ast20201!";
            
            $conn = mysqli_connect($servername, $username, $password);
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            
            if($eid!="10106"||$eid!="10201"||$eid!="10303"){
                echo "<div class=\"account_list\"><table border=\"2px solid black\" style=\"color: black; margin-right:40px\">";
                echo "<tr>";
                echo "<td><b>EID</b></td>";
                echo "<td><b>Student Name</b></td>";
                echo "<td><b>Status</b></td>";
                echo "<td><b>Action</b></td>";
                echo "</tr>";
                $sql = "select * from sams.account_list where eid!=10106 and eid!=10201 and eid!=10303";

                if($result = mysqli_query($conn, $sql)){
                    //if(mysqli_num_rows($result) == 0){
                    while($row = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$row["eid"]."</td>";
                        echo "<td>".$row["name"]."</td>";
                        echo "<td id=\"status".$row["eid"]."\" style=\"color: red\">Absent</td>";
                        echo "<td width=\"80px\" id=\"".$row["eid"]."\"><button onclick=\"setStudentEID('".$row["eid"]."'); setStudentName('".$row["name"]."'); hideBtn('".$row["eid"]."'); insertHistory()\">Take Attendance</button></td>";
                        echo "</tr>";
                    }
                    echo "</table></div>";
                    //}    
                }
        }
            
            
            mysqli_close($conn);
        ?>
    </body>
