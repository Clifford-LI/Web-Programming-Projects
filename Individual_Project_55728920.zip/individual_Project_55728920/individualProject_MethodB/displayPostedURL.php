<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Processing...</title>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
        <style>
            URL_list{
                text-align: left;
                color: black;
            }
        </style>
<script>
function setCookie(cname,cvalue,exdays) {
  var d = new Date();
  d.setTime(d.getTime() + (exdays*24*60*60*1000));
  var expires = "expires=" + d.toGMTString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}
function getCookie(cname) {
      var name = cname + "=";
      var decodedCookie = decodeURIComponent(document.cookie);
      var ca = decodedCookie.split(';');
      for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          return c.substring(name.length, c.length);
        }
      }
      return "";
    }
function clearCookie() {
      setCookie("eid","",-1);
      setCookie("pwd","",-1);
      setCookie("courseID","",-1);
      setCookie("url_id","",-1);
      setCookie("studentEID","",-1);
      setCookie("classStartTime","",-1);
      setCookie("studentName","",-1);
      setCookie("classTitle","",-1);
      setCookie("classDuration","",-1);
      alert("Log out successfully!");
      window.location.href="login.html";
    }
function checkCookie() {
      var eid=getCookie("eid");
      var pwd=getCookie("pwd");
      $.ajax({
            type:"POST",
            async: false,
            url:"accountCheck.php",
            data:{
                eid: eid,
                pwd: pwd
            },
            success: function(data){ 
                $(".accountDisplay").html(data);
                $("#nameDisplay_mobile").html(data);
            }
        })   
}  

function setURLID(url_id){
    setCookie("url_id",url_id,1);
}
function setSID(sid){
    setCookie("sid",sid,1);
}
function setClassStartTime(time){
    var date = new Date();
    var dateStr =
        (date.getFullYear()) + "-" +
        ("00" + (date.getMonth()+1)).slice(-2) + "-" +
        date.getDate() + " " +
        ("00" + date.getHours()).slice(-2) + ":" +
        ("00" + date.getMinutes()).slice(-2) + ":" +
        ("00" + date.getSeconds()).slice(-2);
    
    setCookie("classStartTime",time,1);
    setCookie("clickTime", dateStr, 1);
}
function setClassEndTime(time){
    setCookie("classEndTime",time,1);
}
function setClassTitle(title){
    setCookie("classTitle",title,1);
}
function setClassDuration(duration){
    setCookie("classDuration",duration,1);
}
function takeAttendance_student(){
    $.ajax({
        type:"POST",
        url:"historyProcessing.php",
        data:{
            courseID: getCookie("courseID"),
            url_id: getCookie("url_id"),
            studentEID: getCookie("eid"),
            classStartTime: getCookie("classStartTime"),
            studentName: getCookie("name"),
            classTitle: getCookie("classTitle"),
            classDuration: getCookie("classDuration"),
            attend_time: getCookie("clickTime")
            
        },
        success: function(data){
           $("#aa").html(data);
        }
    });
}
function compareTime(){
    var date = new Date();
    var dateStr =
        (date.getFullYear()) + "-" +
        ("00" + (date.getMonth()+1)).slice(-2) + "-" +
        date.getDate() + " " +
        ("00" + date.getHours()).slice(-2) + ":" +
        ("00" + date.getMinutes()).slice(-2) + ":" +
        ("00" + date.getSeconds()).slice(-2);
        
    var reggie = /(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})/;
    var dateArray1 = reggie.exec(getCookie("clickTime")); 
    var dateArray2 = reggie.exec(getCookie("classStartTime")); 
    var dateArray3 = reggie.exec(getCookie("classEndTime")); 
    var dateObject1 = new Date(
        (+dateArray1[1]),
        (+dateArray1[2])-1, 
        (+dateArray1[3]),
        (+dateArray1[4]),
        (+dateArray1[5]),
        (+dateArray1[6])
    );
    var dateObject2 = new Date(
        (+dateArray2[1]),
        (+dateArray2[2])-1, 
        (+dateArray2[3]),
        (+dateArray2[4]),
        (+dateArray2[5]),
        (+dateArray2[6])
    );
    var dateObject3 = new Date(
        (+dateArray3[1]),
        (+dateArray3[2])-1, 
        (+dateArray3[3]),
        (+dateArray3[4]),
        (+dateArray3[5]),
        (+dateArray3[6])
    );
    if(dateObject1 >= dateObject2 && dateObject1 < dateObject3){
        alert("Welcome to the class of AST"+getCookie("courseID")+"! Attendance has been taken.");
        takeAttendance_student();
    }
    else
        alert("Please attend the class \""+getCookie("classTitle")+"\" on specified time interval!");
}
</script>
    </head>
    <div id="aa"></div>
    <body onload="checkCookie()">
        <?php
            $eid = $_POST['eid'];
            $courseID = $_POST['courseID'];
            
            $servername = "localhost";
            $username = "root";
            $password = "Ast20201!";
            
            $conn = mysqli_connect($servername, $username, $password);
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            
            $sql = "select * from sams.teaching_url where teacher_eid=".$courseID;
            echo "<div class=\"URL_list\"><table border=\"2px solid black\" style=\"color: black\">";
            echo "<tr>";
            echo "<td><b>Course</b></td>";
            echo "<td style=\"padding-right: 80px;\"><b>Title</b></td>";
            echo "<td><b>Class Type</b></td>";
            echo "<td><b>Start Time</b></td>";
            echo "<td><b>Duration</b></td>";
            echo "<td><b>End Time</b></td>";
            echo "<tr>";
            if($result = mysqli_query($conn, $sql)){
                //if(mysqli_num_rows($result) == 0){
                    while($row = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>AST".$row["teacher_eid"]."</td>";
                        if($eid != $courseID)
                            echo "<td style=\"cursor: pointer;\" onclick=\"setURLID('".$row["url_id"]."'); setSID('".$eid."'); setClassStartTime('".$row["start_time"]."'); setClassEndTime('".$row["end_time"]."');  setClassTitle('".$row["title"]."'); setClassDuration('".$row["duration"]."'); compareTime();\" class=\"url_id\"><a style=\"color: blue; text-decoration: underline;\">".$row["title"]."</a></td>";
                        else
                            echo "<td style=\"cursor: pointer;\" onclick=\"setURLID('".$row["url_id"]."'); setClassStartTime('".$row["start_time"]."'); setClassTitle('".$row["title"]."'); setClassDuration('".$row["duration"]."'); window.location.href='takeAttendance_teacher.html'\" id=\"url_id\"><a style=\"color: blue\">".$row["title"]."</a></td>";
                        echo "<td style=\"text-transform: uppercase\">".$row["class_type"]."</td>";
                        echo "<td>".$row["start_time"]."</td>";
                        echo "<td>".$row["duration"]."</td>";
                        echo "<td>".$row["end_time"]."</td>";
                        echo "</tr>";
                    }
                    echo "</table></div>";
                //}    
            }
            mysqli_close($conn);
        ?>
    </body>