<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Displaying History...</title>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
        <style>
            URL_list{
                text-align: left;
            }
        </style>
    </head>
    <body>
        <?php
            $eid = $_POST['eid'];
            
            $servername = "localhost";
            $username = "root";
            $password = "Ast20201!";
            
            $conn = mysqli_connect($servername, $username, $password);
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }

            if($eid=="10106"||$eid=="10201"||$eid=="10303"){
                echo "<div class=\"all_history_list\"><table border=\"2px solid black\" style=\"color: black\">";
                echo "<tr>";
                echo "<td><b>Name</b></td>";
                echo "<td style=\"padding-right: 80px;\"><b>Title of Attended Class</b></td>";
                echo "<td><b>Course Code</b></td>";
                echo "<td><b>Class Start Time</b></td>";
                echo "<td><b>Status</b></td>";
                echo "<td><b>Attend Time</b></td>";
                echo "</tr>";
                $sql = "select distinct class_title, name, attended_course, start_time, duration, attend_time from sams.attendance_history where attended_course='AST".$eid."'";
                if($result = mysqli_query($conn, $sql)){
                    while($row = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$row["name"]."</td>";
                        echo "<td style=\"padding-right: 80px;\">".$row["class_title"]."</td>";
                        echo "<td>".$row["attended_course"]."</td>";
                        echo "<td>".$row["start_time"]."</td>";
                        if($row["attended_course"]=="")
                            echo "<td style=\"color: red\">Absent</td>";
                        else
                            echo "<td>Present</td>";
                        echo "<td>".$row["attend_time"]."</td>";
                        echo "</tr>";
                    }   
                }            
                echo "</table></div>";  
            } 
            mysqli_close($conn);
        ?>

  </body>
