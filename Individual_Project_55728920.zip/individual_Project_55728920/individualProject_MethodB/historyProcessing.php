<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Processing History...</title>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
    </head>
    <body>
        <?php
            $studentEID = $_POST['studentEID'];
            $studentName = $_POST['studentName'];
            $courseID = $_POST['courseID'];
            $url_id = $_POST['url_id'];
            $classTitle = $_POST['classTitle'];
            $classStartTime = $_POST['classStartTime'];
            $classDuration = $_POST['classDuration'];
            $attend_time = $_POST['attend_time'];
            
            $servername = "localhost";
            $username = "root";
            $password = "Ast20201!";
            
            $conn = mysqli_connect($servername, $username, $password);
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            $result=-1;
            echo $studentEID." ".$studentName." ".$courseID." ".$url_id." ".$classTitle." ".$classStartTime." ".$classDuration." ".$attend_time;
            $sql = "insert into sams.attendance_history (ref_no, url_id, eid, name, attended_course, class_title, start_time, duration, attend_time) values (LPAD(FLOOR(RAND() * 99999999.99), 8, '0'), ".$url_id.", ".$studentEID.", '".$studentName."', 'AST".$courseID."', '".$classTitle."', '".$classStartTime."', '".$classDuration."', '".$attend_time."')";
            $result = mysqli_query($conn, $sql);
            if($result!=-1)
                echo "succ";
            else
                echo "fail";
            mysqli_close($conn);
        ?>
    </body>