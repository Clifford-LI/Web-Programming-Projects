<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Login Check |SAMS</title>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
    </head>
    <body>
        <?php
            $eid = $_POST['eid'];
            $pwd = $_POST['pwd'];
            
            $servername = "localhost";
            $username = "root";
            $password = "Ast20201!";
            
            $conn = mysqli_connect($servername, $username, $password);
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }

            $sql = "select * from sams.account_list where eid=".$eid;
            if($result = mysqli_query($conn, $sql)){
                if(mysqli_num_rows($result) == 0){
                    echo 'EID does not exist!';
                }
                else{
                    $row = mysqli_fetch_array($result);
                    if($row['eid']==$eid)
                        if($row['pwd']==$pwd){
                            echo 'Welcome, '.$row['name'].'!';
                            echo "<br>&nbsp;&nbsp;<a href=\"dashboard.html\" style=\"color: yellow; text-decoration: none;\"> ->DASHBOARD-< </a>";
                            
                        }
                        else
                            echo 'Password incorrect!';
                }
                    
            }
            mysqli_close($conn);
        ?>
    </body>
</html>
