<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Posting URL...</title>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
    </head>
    
    <body>
         <?php
            $eid = $_POST['eid'];
            $class_type = $_POST['class_type'];
            $url = $_POST['url'];
            $title = $_POST['title'];
            $class_begin_time = $_POST['class_begin_time'];
            
            $servername = "localhost";
            $username = "root";
            $password = "Ast20201!";
            
            $conn = mysqli_connect($servername, $username, $password);
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }

                if($class_type == "lecture"){
                    $sql = "insert into sams.teaching_url (url_id, teacher_eid, title, url_link, class_type, duration, start_time) values (LPAD(FLOOR(RAND() * 99999999.99), 8, '0'), ".$eid.", '".$title."', '".$url."', '".$class_type."', '2h', '".$class_begin_time."')";
                    $sql_2="update sams.teaching_url set end_time=TIMESTAMPADD(hour,2,start_time) where duration='2h';";
                }else{
                    $sql = "insert into sams.teaching_url (url_id, teacher_eid, title, url_link, class_type, duration, start_time) values (LPAD(FLOOR(RAND() * 99999999.99), 8, '0'), ".$eid.", '".$title."', '".$url."', '".$class_type."', '1h', '".$class_begin_time."')";
                    $sql_2="update sams.teaching_url set end_time=TIMESTAMPADD(hour,1,start_time) where duration='1h';";
                }
                if(mysqli_query($conn, $sql)&&mysqli_query($conn, $sql_2))
                    echo "<span id=\"alert\">Successfully posted!</span>";
                else
                    echo "<span id=\"alert\">Error: failed to post URL.</span>";

            mysqli_close($conn);
        ?>
      
    </body>