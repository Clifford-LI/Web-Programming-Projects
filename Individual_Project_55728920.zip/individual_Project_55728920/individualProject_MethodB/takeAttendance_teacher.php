<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Processing...</title>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
        
    </head>
    <style>
            URL_list{
                text-align: left;
            }
            button{
                border: none; 
                color: white; 
                background-color: #d11d80; 
                width: 90px; 
                height: 40px; 
                cursor:pointer; 
                font-weight: bold;
            }
        </style>

    <body>
        <?php
            $url_id=$_POST['url_id'];
            $studentEID=$_POST['studentEID'];
            $studentName=$_POST['studentName'];
            $courseID=$_POST['courseID'];
            $classStartTime=$_POST['classStartTime'];
            $classTitle=$_POST['classTitle'];
            $classDuration=$_POST['classDuration'];
            $attend_time=$_POST['attend_time'];
            $servername = "localhost";
            $username = "root";
            $password = "Ast20201!";
            
            $conn = mysqli_connect($servername, $username, $password);
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            echo $studentName;  
            $sql = "insert into sams.attendance_history (ref_no, url_id, eid, name, attended_course, class_title, start_time, duration, attend_time) values (LPAD(FLOOR(RAND() * 99999999.99), 8, '0'), ".$url_id.", ".$studentEID.", '".$studentName."', 'AST".$courseID."', '".$classTitle."', '".$classStartTime."', '".$classDuration."', '".$attend_time."')";
            
            if(mysqli_query($conn, $sql))
                    echo "<span>Successful!</span>";
                else
                    echo "<span>Error: failed.</span>";
            mysqli_close($conn);
        ?>
        
    </body>
