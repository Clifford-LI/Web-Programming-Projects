-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sams
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account_list`
--

DROP TABLE IF EXISTS `account_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_list` (
  `eid` varchar(10) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `pwd` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`eid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_list`
--

LOCK TABLES `account_list` WRITE;
/*!40000 ALTER TABLE `account_list` DISABLE KEYS */;
INSERT INTO `account_list` VALUES ('10106','Dr PANG','10106'),('10201','Dr Bell LIU','10201'),('10303','Dr Farah YAN','10303'),('55721309','CHUNG Shun Lok','732109'),('55721310','TANG Audric Pak Hang','732110'),('55721311','LEE Ho Yin','732111'),('55721312','LING Tsz Wo','732112'),('55721313','ZHOU Huipeng','732113'),('55721314','CHEUNG Siu Fung','732114'),('55721315','SHERAAZ-RAFIQ','732115'),('55721416','LAM Man Wai','732116'),('55721417','AU Wing Kin','732117'),('55721418','MAK Tsz Fung','732118'),('55721419','LEUNG Yui Chit','732119'),('55721420','CHOI Chun Leuk','732120'),('55721421','KONG Kin Chun','732121'),('55721422','LEE Ho Ming','732122'),('55721423','XING Yutong','732123'),('55721424','HE Jingshen','732124'),('55723318','FONG Siu Tung','732132'),('55723319','YIP Shi Shing','732133'),('55723320','XU Jiaying','732134'),('55723321','XIE Qichen','732135'),('55723323','CAI Yide','732137'),('55723324','YUEN Chun Ho','732138'),('55723325','KWONG Tak Wai','732139'),('55725640','CHAN Kam Ming','732140'),('55725641','OUYANG Xiaolong','732141'),('55725642','FUNG Kwan Tai','732142'),('55725643','PANG Chu Man','732143'),('55725644','FAN Ho Wang','732144'),('55725645','CHAN Yuet Chi','732145'),('55725646','HO Man Ho','732146'),('55725647','CHONG Chi Ho','732147'),('55725648','HOI Wai San','732148'),('55725649','LAM Pui Chung','732149'),('55725650','HO Tsz King','732150'),('55725651','CHEUNG Chin Hang','732151'),('55725652','LO Hon Chak','732152'),('55725653','WONG Shuk Kwan','732153'),('55725654','YAN Haochen','732154'),('55725655','YEUNG Tak Hei','732155'),('55725656','LEUNG Wing Shing','732156'),('55725657','BHATT Arun Datt','732157'),('55728421','CHAN Tsz Long','732125'),('55728422','LIN Hon Chuen','732126'),('55728423','NG Tai Fung','732127'),('55728424','CHAN Chun Fung','732128'),('55728425','LAU Wai Sum','732129'),('55728426','FAN Cheuk Nam','732130'),('55728427','WONG Chun Kit','732131'),('55728920','LI Hongzhou','732136');
/*!40000 ALTER TABLE `account_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance_history`
--

DROP TABLE IF EXISTS `attendance_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance_history` (
  `ref_no` int NOT NULL,
  `url_id` int DEFAULT NULL,
  `eid` int DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `attended_course` varchar(100) DEFAULT NULL,
  `class_title` varchar(100) DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `duration` varchar(45) DEFAULT NULL,
  `attend_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ref_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance_history`
--

LOCK TABLES `attendance_history` WRITE;
/*!40000 ALTER TABLE `attendance_history` DISABLE KEYS */;
INSERT INTO `attendance_history` VALUES (15184790,21006308,55728920,'LI Hongzhou','AST10201','Lecture 13: Review','2020-05-19 10:30:00','2h','2020-05-19 10:30:09'),(19223779,68138948,55728422,'LIN Hon Chuen','AST10201','Mid-term Test','2020-05-15 03:12:00','2h','2020-05-19 10:21:30'),(20262881,68138948,55728421,'CHAN Tsz Long','AST10201','Mid-term Test','2020-05-15 03:12:00','2h','2020-05-19 10:21:30'),(23469667,7091216,55728920,'LI Hongzhou','AST10201','Tutorial 13: Review','2020-05-19 10:25:00','1h','2020-05-19 10:28:13'),(25249209,68138948,55721312,'LING Tsz Wo','AST10201','Mid-term Test','2020-05-15 03:12:00','2h','2020-05-19 10:21:28'),(29220470,68138948,55728920,'LI Hongzhou','AST10201','Mid-term Test','2020-05-15 03:12:00','2h','2020-05-19 10:21:31'),(33833913,68138948,55721315,'SHERAAZ-RAFIQ','AST10201','Mid-term Test','2020-05-15 03:12:00','2h','2020-05-19 10:21:28'),(36664673,7091216,55728425,'LAU Wai Sum','AST10201','Tutorial 13: Review','2020-05-19 10:25:00','1h','2020-05-19 10:28:15'),(56684465,7091216,55728421,'CHAN Tsz Long','AST10201','Tutorial 13: Review','2020-05-19 10:25:00','1h','2020-05-19 10:28:17'),(65475291,68138948,55721309,'CHUNG Shun Lok','AST10201','Mid-term Test','2020-05-15 03:12:00','2h','2020-05-19 10:21:27'),(66618158,68138948,55721314,'CHEUNG Siu Fung','AST10201','Mid-term Test','2020-05-15 03:12:00','2h','2020-05-19 10:21:28'),(73470828,7091216,55728424,'CHAN Chun Fung','AST10201','Tutorial 13: Review','2020-05-19 10:25:00','1h','2020-05-19 10:28:14');
/*!40000 ALTER TABLE `attendance_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teaching_url`
--

DROP TABLE IF EXISTS `teaching_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teaching_url` (
  `url_id` int NOT NULL,
  `teacher_eid` int DEFAULT NULL,
  `title` varchar(45) DEFAULT NULL,
  `url_link` varchar(200) DEFAULT NULL,
  `class_type` varchar(45) DEFAULT NULL,
  `duration` varchar(45) DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`url_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teaching_url`
--

LOCK TABLES `teaching_url` WRITE;
/*!40000 ALTER TABLE `teaching_url` DISABLE KEYS */;
INSERT INTO `teaching_url` VALUES (3070467,10106,'Lecture 2','Write URL here...','lecture','2h','2020-07-16 06:11:00','2020-07-16 08:11:00'),(7091216,10201,'Tutorial 13: Review','fdsafds','tutorial','1h','2020-05-19 10:25:00','2020-05-19 11:25:00'),(18834261,10303,'Tutorial 2','fdasfdsa','tutorial','1h','2020-05-18 09:50:00','2020-05-18 10:50:00'),(19161851,10303,'Lecture 2','fdsafdsa','lecture','2h','2020-05-18 10:50:00','2020-05-18 12:50:00'),(20973487,10201,'Lab 2','fsdafsaf','tutorial','1h','2020-05-28 00:12:00','2020-05-28 01:12:00'),(21006308,10201,'Lecture 13: Review','fsafafds','lecture','2h','2020-05-19 10:30:00','2020-05-19 12:30:00'),(22146753,10201,'Lecture 11','fdafaf','lecture','2h','2020-05-22 05:22:00','2020-05-22 07:22:00'),(28111666,10106,'Lecuture 3','Write URL here...','lecture','2h','2020-05-22 04:58:00','2020-05-22 06:58:00'),(30317466,10303,'Lecture 3','google.com','lecture','2h','2020-12-12 04:12:00','2020-12-12 06:12:00'),(68138948,10201,'Mid-term Test','dfd','lecture','2h','2020-05-15 03:12:00','2020-05-15 05:12:00'),(68785888,10201,'Lecture 12: MIPS','tgdd','lecture','2h','2020-05-14 07:02:00','2020-05-14 09:02:00'),(68851805,10106,'Lecture 1: Introduction to Java Programming','ast10106_course_link.html','lecture','2h','2020-05-15 13:06:00','2020-05-15 15:06:00'),(75588170,10201,'Lecture 1: Introduction to CO','google.com','lecture','2h','2020-05-16 02:22:00','2020-05-16 04:22:00'),(80843410,10303,'Tutorial 3','fdsafs','tutorial','1h','2020-05-19 04:11:00','2020-05-19 05:11:00'),(82239736,10303,'Lecture 1: Introduction','fdsaf','lecture','2h','2020-12-21 16:22:00','2020-12-21 18:22:00'),(93347200,10106,'Tutorial 3','afsadfdasd','tutorial','1h','2020-12-11 17:21:00','2020-12-11 18:21:00'),(93793254,10106,'Tutorial 2','ttt','tutorial','1h','2020-12-11 17:02:00','2020-12-11 18:02:00'),(95164021,10106,'Tutorial 11: PHP','fdasadsfsaf','lecture','2h','2020-05-25 00:00:00','2020-05-25 02:00:00'),(97158416,10201,'Tutorial 1','dsafsa','tutorial','1h','2020-12-24 08:34:00','2020-12-24 09:34:00');
/*!40000 ALTER TABLE `teaching_url` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-19 18:51:29
